from fenics import *
from mshr import *
import numpy, time, ufl
import numpy as np

parameters["form_compiler"]["representation"] = "uflacs"
parameters["form_compiler"]["cpp_optimize"] = True
parameters["form_compiler"]["optimize"] = True

tp1 = time.time()

"Generate mesh"
#----------------------------------------------------------------------------------------------------------------------------------------------------
P0 = Point(-1.0, -0.5, -1.0)
P1 = Point( 1.0,  0.5,  1.0)
nx=ny=nz=10
mesh = BoxMesh(P0, P1, nx, ny, nz)

"mark boundaries"
#----------------------------------------------------------------------------------------------------------------------------------------------------
class Inlet(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and near(x[2], -1.0)
		
class Outlet(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and near(x[2], 1.0)
		
class Walls(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and (near(x[1], -0.5) or near(x[1], 0.5))
		
class Interface(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and (near(x[0], -1.0) or near(x[0], 1.0))

parts = FacetFunction('size_t', mesh)
parts.set_all(0)
DomainBoundary().mark(parts, 5)
Inlet().mark(parts, 1)
Outlet().mark(parts, 2)
Walls().mark(parts, 3)
Interface().mark(parts, 4)
ds = Measure("ds",domain=mesh,subdomain_data=parts)

"Parametro de malha"
#----------------------------------------------------------------------------------------------------------------------------------------------------
h = []
for cell in cells(mesh):
    h.append(cell.inradius())

"parameters for rigid problem"
#----------------------------------------------------------------------------------------------------------------------------------------------------
#Parameters for time
h_min   = mesh.hmin()
V_max   = 12.5
dt      = 0.005 #0.1*h_min/(V_max*2.0)
t_end   = 3.0
n       = int(t_end/dt + 1.0)
dt      = t_end/n
k       = Constant(dt)
t_range = np.linspace(0, t_end, n+1)[1:]

#Parameters for fluid
mu_f  = 0.04
rho_f = 1.06
nu_f  = Constant(mu_f/rho_f)
f     = Constant((0.0, 0.0, 0.0))

"Function Space"
#----------------------------------------------------------------------------------------------------------------------------------------------------
V = VectorFunctionSpace(mesh, 'P', 1)
P = FunctionSpace(mesh, 'P', 1)
W = MixedFunctionSpace([V, P])

"boundaries condition"
#----------------------------------------------------------------------------------------------------------------------------------------------------
vin    = Expression(('0.0', '0.0', 'Vm*(1.0 - x[0]*x[0])'), Vm=V_max, degree=3)
vwalls = Constant((0.0, 0.0, 0.0))
pout   = Constant(2660.0)

bcvin        = DirichletBC(W.sub(0), vin, parts, 1)
bcvwalls     = DirichletBC(W.sub(0), vwalls, parts, 3)
bcvinterface = DirichletBC(W.sub(0), vwalls, parts, 4)
bcpout       = DirichletBC(W.sub(1), pout, parts, 2)

bcs = [bcvin, bcvwalls, bcvinterface, bcpout]

"Functions for deformable problem"
#----------------------------------------------------------------------------------------------------------------------------------------------------
w, q   = TestFunctions(W)
vp     = TrialFunction(W)
v, p   = ufl.split(vp)

vp_    = Function(W)
v_, p_ = vp_.split()

w_n = Function(W)
v_n,  p_n = w_n.split(True)

"Tensor normal and identity"
#----------------------------------------------------------------------------------------------------------------------------------------------------
n = FacetNormal(mesh)
I = Identity(mesh.geometry().dim())

"Tensors for fluid"
#----------------------------------------------------------------------------------------------------------------------------------------------------
def epsilon_f(v):
	return sym(nabla_grad(v))
	
def sigma_f(v, p, mu_f):
	return 2*mu_f*epsilon_f(v) - p*I

"Stokes problem"
#----------------------------------------------------------------------------------------------------------------------------------------------------
F = inner(sigma_f(v, p, mu_f), epsilon_f(w))*dx - q*nabla_div(v)*dx - rho_f*inner(f, w)*dx + inner(p*n, w)*ds(2) - mu_f*inner(w, grad(v).T*n)*ds(2)

"add convective term"
#----------------------------------------------------------------------------------------------------------------------------------------------------
F += rho_f*inner(dot(v_, nabla_grad(v)), w)*dx

"add transient term"
#----------------------------------------------------------------------------------------------------------------------------------------------------
F += (rho_f/k)*inner(v - v_n, w)*dx

"Parameters for stabilizing"
#----------------------------------------------------------------------------------------------------------------------------------------------------
h = CellSize(mesh)
vnorm = sqrt(dot(v_, v_))

"Residue"
#----------------------------------------------------------------------------------------------------------------------------------------------------
R = (rho_f/k)*(v - v_n) + rho_f*dot(v_, nabla_grad(v)) - div(sigma_f(v, p, mu_f)) - rho_f*f

"Term PSPG"
#----------------------------------------------------------------------------------------------------------------------------------------------------
tau_pspg = (h**2)/2.0
F_pspg   = (tau_pspg/rho_f)*inner(R, nabla_grad(q))*dx

"Term SUPG"
#----------------------------------------------------------------------------------------------------------------------------------------------------
tau_supg = ((2.0/k)**2 + (2*vnorm/h)**2 + 9*(4*nu_f/(h**2))**2)**(-0.5)
F_supg   = tau_supg*inner(R, dot(v_,nabla_grad(w)))*dx

"Term LSIC"
#----------------------------------------------------------------------------------------------------------------------------------------------------
tau_lsic = vnorm*h/2.0
F_lsic = rho_f*tau_lsic*inner(nabla_div(v), nabla_div(w))*dx

"Add stabilizing terms"
#----------------------------------------------------------------------------------------------------------------------------------------------------
F += -F_pspg + F_supg + F_lsic

"Mounting the problem"
#----------------------------------------------------------------------------------------------------------------------------------------------------
F_      = action(F, vp_)
J_      = derivative(F_, vp_, vp)
problem = NonlinearVariationalProblem(F_, vp_, bcs, J_)
solver  = NonlinearVariationalSolver(problem)

"Solution control"
#----------------------------------------------------------------------------------------------------------------------------------------------------
solver.parameters['nonlinear_solver'] = 'newton'
prm = solver.parameters['newton_solver']
prm['relative_tolerance']                                   = 1.0E-5
prm['absolute_tolerance']                                   = 1.0E-5
prm['maximum_iterations']                                   = 100
prm['error_on_nonconvergence']                              = False
prm['linear_solver']                                        = 'gmres'
prm['preconditioner']                                       = 'ilu'
prm['krylov_solver']['relative_tolerance']                  = 1.0E-8
prm['krylov_solver']['absolute_tolerance']                  = 1.0E-8
prm['krylov_solver']['maximum_iterations']                  = 10000
prm['krylov_solver']['error_on_nonconvergence']             = True
prm['krylov_solver']['preconditioner']['ilu']['fill_level'] = 0

"parameters for the loop in time"
#----------------------------------------------------------------------------------------------------------------------------------------------------
count = 0
tol   = 1.0E-5
set_log_active(False)

tp2 = time.time()

vel   = File("Results/Rigid/%s/velocity.xdmf" % str(name))
pres  = File("Results/Rigid/%s/pressure.xdmf" % str(name))

"Solver the problem"
#----------------------------------------------------------------------------------------------------------------------------------------------------
for t in t_range:
	count +=1
	
	#solve 
	solver.solve()
	
	#split
	v_, p_ = vp_.split(True)
	
	#norm of velocity
	diff1 = v_.vector() - v_n.vector()
	eps1  = np.linalg.norm(diff1, ord=2)
	norm1 = norm(v_)
	en1   = eps1/norm1

	
	#update
	v_n.assign(v_)
	p_n.assign(p_)
	
	#print data
	print ""
	s = "time step = %d, currentily time = %.15g, relative erro = %.15g, absolute erro = %.15g, P1, Rigid Problem" \
			% (count, t, en1, eps1)
			
	print s + "\n" + len(s)*"-"
	
	#convergence
	if ( (en1 < tol) or (t > t_end)): break

tp3 = time.time()

filedata = 'tempo.log'

arq = open(filedata, 'a')
arq.write("\n\n%s\n\n%s %.15g\n%s %.15g\n%s %.15g\n" % (str("Rigid Problem "),str("compiler time :"), tp2-tp1, str("solver time ==:"), tp3-tp2, str("cpu time =====:"), tp3-tp1))
arq.close() 

output = HDF5File(mesh.mpi_comm(), 'Results/Rigid/output/velocity.h5', 'w')
output.write(v_, 'velocity')
output = HDF5File(mesh.mpi_comm(), 'Results/Rigid/output/pressure.h5', 'w')
output.write(p_, 'pressure')

#save solution
vel << v_
pres << p_

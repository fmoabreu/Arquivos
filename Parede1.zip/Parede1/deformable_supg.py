from fenics import *
from mshr import *
import numpy, time, ufl
import numpy as np

parameters["form_compiler"]["representation"] = "uflacs"
parameters["form_compiler"]["cpp_optimize"] = True
parameters["form_compiler"]["optimize"] = True

tp1 = time.time()

"Generate mesh"
#------------------------------------------------------------------------------------------------------
P0 = Point(-1.0, -0.5, -1.0)
P1 = Point( 1.0,  0.5,  1.0)
nx=ny=nz=10
mesh = BoxMesh(P0, P1, nx, ny, nz)

"mark boundaries"
#------------------------------------------------------------------------------------------------------
class Inlet(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and near(x[2], -1.0)
		
class Outlet(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and near(x[2], 1.0)
		
class Walls(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and (near(x[1], -0.5) or near(x[1], 0.5))
		
class Interface(SubDomain):
	def inside(self, x, on_boundary):
		return on_boundary and (near(x[0], -1.0) or near(x[0], 1.0))

parts = FacetFunction('size_t', mesh)
parts.set_all(0)
DomainBoundary().mark(parts, 6)
Inlet().mark(parts, 1)
Outlet().mark(parts, 2)
Walls().mark(parts, 3)
Interface().mark(parts, 4)
ds = Measure("ds",domain=mesh,subdomain_data=parts)

"Parametro de malha"
#------------------------------------------------------------------------------------------------------
h = []
for cell in cells(mesh):
    h.append(cell.inradius())

"parameters for rigid problem"
#------------------------------------------------------------------------------------------------------
#Parameters for time
h_min   = mesh.hmin()
V_max   = 12.5
dt      = 0.005 #0.1*h_min/(V_max*2.0)
t_end   = 3.0
n       = int(t_end/dt + 1.0)
dt      = t_end/n
k       = Constant(dt)
t_range = np.linspace(0, t_end, n+1)[1:]

#Parameters for fluid
mu_f  = 0.04
rho_f = 1.06
nu_f  = Constant(mu_f/rho_f)
f     = Constant((0.0, 0.0, 0.0))

#Parameters for solid
nu_s  = 0.5
rho_s = 1.09
E     = 5320.0
qsi   = 0.1
ks    = 5.0/6.0
beta  = 1.0

"Function Space"
#------------------------------------------------------------------------------------------------------
V = VectorFunctionSpace(mesh, 'P', 1)
P = FunctionSpace(mesh, 'P', 1)
W = MixedFunctionSpace([V, P])

"boundaries condition"
#------------------------------------------------------------------------------------------------------
vin    = Expression(('0.0', '0.0', 'Vm*(1.0 - x[0]*x[0])'), Vm=V_max, degree=3)
vwalls = Constant((0.0, 0.0, 0.0))
pout   = Constant(2660.0)

bcvin        = DirichletBC(W.sub(0), vin, parts, 1)
bcvwalls     = DirichletBC(W.sub(0), vwalls, parts, 3)
bcpout       = DirichletBC(W.sub(1), pout, parts, 2)

bcs = [bcvin, bcvwalls, bcpout]

"Functions for deformable problem"
#-------------------------------------------------------------------------------------------------------------------------------------
w, q   = TestFunctions(W)
vp     = TrialFunction(W)
v, p   = ufl.split(vp)
u, pd  = ufl.split(vp)

vp_    = Function(W)
v_, p_ = vp_.split()
u_, pd = vp_.split()

w_n = Function(W)
v_n,  p_n = w_n.split(True)
v_2n, pd  = w_n.split(True)
u_n,  pd  = w_n.split(True)

"Tensor normal and identity"
#-------------------------------------------------------------------------------------------------------------------------------------
n = FacetNormal(mesh)
I = Identity(mesh.geometry().dim())

"Tensors for fluid"
#-------------------------------------------------------------------------------------------------------------------------------------
def epsilon_f(v):
	return sym(nabla_grad(v))
	
def sigma_f(v, p, mu_f):
	return 2*mu_f*epsilon_f(v) - p*I

"modified normal and vectors for a membrane approach"
#-------------------------------------------------------------------------------------------------------------------------------------
#Facet normal vector
norm_n = (n[0]*n[0] + n[1]*n[1] + n[2]*n[2])**(1/2.0)
n1     = 1/norm_n*n

#First tangent vector
t1      = as_vector((n1[1] - n1[2], n1[2] - n1[0], n1[0] - n1[1]))
norm_t1 = (t1[0]*t1[0] + t1[1]*t1[1] + t1[2]*t1[2])**(1/2.0)
t1      = 1/norm_t1*t1

#Second tangent vector
t2      = as_vector((n1[1]*t1[2] - n[2]*t1[1], n1[2]*t1[0] - n[0]*t1[2], n1[0]*t1[1] - n[1]*t1[0]))
norm_t2 = (t2[0]*t2[0] + t2[1]*t2[1] + t2[2]*t2[2])**(1/2.0)
t2      = 1/norm_t2*t2

"modified stress and displacement tensor"
#-------------------------------------------------------------------------------------------------------------------------------------
def epsilon_s(u):
	e=grad(u)
	ep = as_vector( [ dot(dot(t1, e), t1), \
			  dot(dot(t2, e), t2), \
			  0.0*dot(dot(n1, e), n1), \
			  dot(dot(t1, e), t2) + dot(dot(t2, e), t1), \
			  dot(dot(n1, e), t1), \
			  dot(dot(n1, e), t2) ] )
					  
	return ep
	
def sigma_s(u):
	C_coef = E/(1.0 - nu_s*nu_s)
	C = as_matrix([[ 1.0, nu_s, 0.0,      0.0      ,        0.0       ,         0.0      ],
                       [nu_s,  1.0, 0.0,      0.0      ,        0.0       ,         0.0      ],
		       [ 0.0,  0.0, 0.0,      0.0      ,        0.0       ,         0.0      ],
		       [ 0.0,  0.0, 0.0, 0.5*(1.0-nu_s),        0.0       ,         0.0      ],
		       [ 0.0,  0.0, 0.0,      0.0      , 0.5*ks*(1.0-nu_s),         0.0      ],
		       [ 0.0,  0.0, 0.0,      0.0      ,         0.0      , 0.5*ks*(1.0-nu_s)]] )
				   
	C = C*C_coef
	
	stress = dot(C,epsilon_s(u))
	
	return stress

"Explicit displacement"
#-------------------------------------------------------------------------------------------------------------------------------------
def disp(u_n, v, v_n, v_2n, k):
        return u_n + k*v_n + (k*k/2.0)*((1.0 - 2.0*beta)*((v_n - v_2n)/k) + 2.0*beta*((v - v_n)/k))

"Form of initialization of the deformation"
#-------------------------------------------------------------------------------------------------------------------------------------
INIT = {"zero_displacement": True,
        "hydrostatic_pressure": False}
        
init = INIT.copy()

"Initialization of the deformation"
#-------------------------------------------------------------------------------------------------------------------------------------
vr, pr = Function(V), Function(P)
bcu    = [DirichletBC(V, vwalls, parts, 1), DirichletBC(V, vwalls, parts, 2), DirichletBC(V, vwalls, parts, 4)]
  
#Import solution
input_file = HDF5File(mesh.mpi_comm(), 'Results/Rigid/output/velocity.h5', 'r')
input_file.read(vr, 'velocity')

input_file = HDF5File(mesh.mpi_comm(), 'Results/Rigid/output/pressure.h5', 'r')
input_file.read(pr, 'pressure')

#zero displacement
if init["zero_displacement"] and not init["hydrostatic_pressure"]:

        v_n.assign(vr)
        v_2n.assign(vr)
        p_n.assign(pr)
        
        name = "zero_displacement"
        
if init["hydrostatic_pressure"] and not init["zero_displacement"]:
        
        pavg = (assemble(pr*ds(4)))/(assemble(Constant(1.0)*ds(4)))
        w1 = TestFunction(V)
        u1 = TrialFunction(V)
        us = Function(V)
        
        Fhp = 1.0E-5*inner(nabla_grad(u1), nabla_grad(w1))*dx + qsi*inner(sigma_s(u1), epsilon_s(w1))*ds(4) - inner(pavg*n, w1)*ds(4)
        
        ahp, Lhp = system(Fhp)
        Ahp, bhp = assemble(ahp), assemble(Lhp)
        [bc.apply(Ahp, bhp) for bc in bcu]
        solve(Ahp, us.vector(), bhp, 'gmres', 'ilu')
        
        v_n.assign(vr)
        v_2n.assign(vr)
        p_n.assign(pr)
        u_n.assign(us)

        name = "hydrostatic_pressure"

if (init["zero_displacement"] and init["hydrostatic_pressure"]):
        raise NotImplementedError

"Stokes problem"
#-------------------------------------------------------------------------------------------------------------------------------------
F = inner(sigma_f(v, p, mu_f), epsilon_f(w))*dx - q*nabla_div(v)*dx - rho_f*inner(f, w)*dx + inner(p*n, w)*ds(2) - mu_f*inner(w, grad(v).T*n)*ds(2)

"add convective term"
#-------------------------------------------------------------------------------------------------------------------------------------
F += rho_f*inner(dot(v_, nabla_grad(v)), w)*dx

"add transient term"
#-------------------------------------------------------------------------------------------------------------------------------------
F += (rho_f/k)*inner(v - v_n, w)*dx

"Coupling the problem"
#-------------------------------------------------------------------------------------------------------------------------------------
F += qsi*(rho_s/k)*inner(v - v_n, w)*ds(4) + qsi*inner(sigma_s(disp(u_n, v, v_n, v_2n, k)), epsilon_s(w))*ds(4)

"Parameters for stabilizing"
#-------------------------------------------------------------------------------------------------------------------------------------
h = CellSize(mesh)
vnorm = sqrt(dot(v_, v_))

"Residue"
#-------------------------------------------------------------------------------------------------------------------------------------
R = (rho_f/k)*(v - v_n) + rho_f*dot(v_, nabla_grad(v)) - div(sigma_f(v, p, mu_f)) - rho_f*f

"Term PSPG"
#-------------------------------------------------------------------------------------------------------------------------------------
tau_pspg = (h**2)/2.0
F_pspg   = (tau_pspg/rho_f)*inner(R, nabla_grad(q))*dx

"Term SUPG"
#-------------------------------------------------------------------------------------------------------------------------------------
tau_supg = ((2.0/k)**2 + (2*vnorm/h)**2 + 9*(4*nu_f/(h**2))**2)**(-0.5)
F_supg   = tau_supg*inner(R, dot(v_,nabla_grad(w)))*dx

"Term LSIC"
#-------------------------------------------------------------------------------------------------------------------------------------
tau_lsic = vnorm*h/2.0
F_lsic = rho_f*tau_lsic*inner(nabla_div(v), nabla_div(w))*dx

"Add stabilizing terms"
#-------------------------------------------------------------------------------------------------------------------------------------
F += -F_pspg + F_supg + F_lsic

"Mounting the problem"
#------------------------------------------------------------------------------------------------------
F_      = action(F, vp_)
J_      = derivative(F_, vp_, vp)
problem = NonlinearVariationalProblem(F_, vp_, bcs, J_)
solver  = NonlinearVariationalSolver(problem)

"Solution control"
#------------------------------------------------------------------------------------------------------
solver.parameters['nonlinear_solver'] = 'newton'
prm = solver.parameters['newton_solver']
prm['relative_tolerance']                                   = 1.0E-5
prm['absolute_tolerance']                                   = 1.0E-5
prm['maximum_iterations']                                   = 100
prm['error_on_nonconvergence']                              = False
prm['linear_solver']                                        = 'gmres'
prm['preconditioner']                                       = 'ilu'
prm['krylov_solver']['relative_tolerance']                  = 1.0E-8
prm['krylov_solver']['absolute_tolerance']                  = 1.0E-8
prm['krylov_solver']['maximum_iterations']                  = 10000
prm['krylov_solver']['error_on_nonconvergence']             = True
prm['krylov_solver']['preconditioner']['ilu']['fill_level'] = 0

"parameters for the loop in time"
#------------------------------------------------------------------------------------------------------
count = 0
set_log_active(False)

tp2 = time.time()

vel   = File("Results/Deformable/%s/velocity.xdmf" % str(name))
pres  = File("Results/Deformable/%s/pressure.xdmf" % str(name))
defor = File("Results/Deformable/%s/displacement.xdmf" % str(name))

Ain  = assemble(Constant(1.0)*ds(1))
Aout = assemble(Constant(1.0)*ds(2))

if (init["zero_displacement"]):

	filedate1 = "Results/Deformable/zero_displacement/ux.dat"
	filedate2 = "Results/Deformable/zero_displacement/uz.dat"
	filedate3 = "Results/Deformable/zero_displacement/vx.dat"
	filedate4 = "Results/Deformable/zero_displacement/vz.dat"
	fluxin  = 'Results/Deformable/zero_displacement/fluxin.dat'
	fluxout = 'Results/Deformable/zero_displacement/fluxout.dat'
	presin  = 'Results/Deformable/zero_displacement/presin.dat'
	presout = 'Results/Deformable/zero_displacement/presout.dat'

if (init["hydrostatic_pressure"]):

	filedate1 = "Results/Deformable/hydrostatic_pressure/ux.dat"
	filedate2 = "Results/Deformable/hydrostatic_pressure/uz.dat"
	filedate3 = "Results/Deformable/hydrostatic_pressure/vx.dat"
	filedate4 = "Results/Deformable/hydrostatic_pressure/vz.dat"
	fluxin  = 'Results/Deformable/hydrostatic_pressure/fluxin.dat'
	fluxout = 'Results/Deformable/hydrostatic_pressure/fluxout.dat'
	presin  = 'Results/Deformable/hydrostatic_pressure/presin.dat'
	presout = 'Results/Deformable/hydrostatic_pressure/presout.dat'

x11 = np.array((-1.0, -0.4, 0.0))
x12 = np.array((-1.0,  0.4, 0.0))
x13 = np.array(( 1.0, -0.4, 0.0))
x14 = np.array(( 1.0,  0.4, 0.0))


"Solver the problem"
#------------------------------------------------------------------------------------------------------
for t in t_range:
	count +=1

	disp11 = np.array((0.0, 0.0, 0.0))
	disp12 = np.array((0.0, 0.0, 0.0))
	disp13 = np.array((0.0, 0.0, 0.0))
	disp14 = np.array((0.0, 0.0, 0.0))
	vel11  = np.array((0.0, 0.0, 0.0))
	vel12  = np.array((0.0, 0.0, 0.0))
	vel13  = np.array((0.0, 0.0, 0.0))
	vel14  = np.array((0.0, 0.0, 0.0))
	
	#solve 
	solver.solve()
	
	#split
	v_, p_ = vp_.split(True)
	
	#Compute explicit displacement
	u_ = disp(u_n, v_, v_n, v_2n, k)
	u_ = project(u_, V)	
	
	#norm of velocity
	diff1 = v_.vector() - v_n.vector()
	eps1  = np.linalg.norm(diff1, ord=2)
	norm1 = norm(v_)
	en1   = eps1/norm1
	
	#displacement nodal: 11, 12, 13, 14
	u_.eval(disp11, x11)
	u_.eval(disp12, x12)
	u_.eval(disp13, x13)
	u_.eval(disp14, x14)

	#velocity nodal: 11, 12, 13, 14
	v_.eval(vel11, x11)
	v_.eval(vel12, x12)
	v_.eval(vel13, x13)
	v_.eval(vel14, x14)
		
	arq = open(filedate1, 'a')
	arq.write("%.15g %.15g %.15g %.15g %.15g\n" % (disp11[0], disp12[0], disp13[0], disp14[0], t))
	arq.close()

	arq = open(filedate2, 'a')
	arq.write("%.15g %.15g %.15g %.15g %.15g\n" % (disp11[2], disp12[2], disp13[2], disp14[2], t))
	arq.close()
	
	arq = open(filedate3, 'a')
	arq.write("%.15g %.15g %.15g %.15g %.15g\n" % (vel11[0], vel12[0], vel13[0], vel14[0], t))
	arq.close()

	arq = open(filedate4, 'a')
	arq.write("%.15g %.15g %.15g %.15g %.15g\n" % (vel11[2], vel12[2], vel13[2], vel14[2], t))
	arq.close()
	
	#update
	v_2n.assign(v_n)
	v_n.assign(v_)
	p_n.assign(p_)
	u_n.assign(u_)
	
	#print data
	print ""
	s = "time step = %d, currentily time = %.15g, relative erro = %.15g, absolute erro = %.15g, P1, Deformable Problem" \
			% (count, t, en1, eps1)
			
	print s + "\n" + len(s)*"-"
	
	#convergence
	if (t > t_end): break

tp3 = time.time()

filedata = 'tempo.log'

arq = open(filedata, 'a')
arq.write("\n\n%s\n\n%s %.15g\n%s %.15g\n%s %.15g\n" % (str("Deformable Problem "),str("compiler time :"), tp2-tp1, str("solver time ==:"), tp3-tp2, str("cpu time =====:"), tp3-tp1))
arq.close() 

#save solution
vel << v_
pres << p_
defor << u_
